//
//  CompoundInterest.swift
//  MyFirstApp
//
//  Created by Student on 3/16/17.
//  Copyright © 2017 Student. All rights reserved.
//

import Foundation
// model for compound interest

class compoundInterest{
    func calculate(loanAmount: Double, interestRate: Double, years: Int) -> Double{
        let interestRate = interestRate/100.0
        let compoundMultiplier = pow(1.0 + interestRate, Double(years))
        
        return loanAmount * compoundMultiplier
    }
}
