//
//  AppDelegate.swift
//  MyFirstApp
//
//  Created by Student on 2/16/17.
//  Copyright © 2017 Student. All rights reserved.
//

import Cocoa


extension Double {
    var dollars: String {
        let formatter: NumberFormatter = NumberFormatter()
        
        var result: String?
        
        formatter.numberStyle = NumberFormatter.Style.currency
        result = formatter.string(from: NSNumber(value: self))
        
        if result == nil{
            return "FORMAT FAILURE!"
        }
        return result!
    }
}


@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    @IBOutlet weak var window: NSWindow!
    
    
    //model
    var simpleInterestCalculator : simpleInterest = simpleInterest()
    var compoundInterestCalculator : compoundInterest = compoundInterest()
    
    @IBOutlet weak var loanAmountTextField: NSTextField!
    @IBOutlet weak var loanTermTextField: NSTextField!
    @IBOutlet weak var resultDisplayField: NSTextField!
    @IBOutlet weak var interestRateTextField: NSTextField!
    
    @IBAction func calculateCompoundButton(_ sender: NSButton) {
        var result : Double
        result = compoundInterestCalculator.calculate(loanAmount: loanAmountTextField.doubleValue, interestRate: interestRateTextField.doubleValue, years: loanTermTextField.integerValue)
        self.resultDisplayField.stringValue = result.dollars
    }
    @IBAction func calculateSimpleButton(_ sender: NSButton) {
        var result : Double
        result = simpleInterestCalculator.calculate(loanAmount:loanAmountTextField.doubleValue, years: loanTermTextField.integerValue, interestRate: interestRateTextField.doubleValue)
        //self.resultDisplayField.stringValue = String(format: "$%.2f",result)
        self.resultDisplayField.stringValue = result.dollars
    }
    
    
    


    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

