

import Foundation



class simpleInterest {
    func calculate(loanAmount : Double, years : Int, interestRate : Double) -> Double {
        let interestRate = interestRate / 100.0
        let interest = Double(years) * interestRate * loanAmount
        return loanAmount + interest
    }
}
