//
//  MyFirstAppTests.swift
//  MyFirstAppTests
//
//  Created by Student on 2/16/17.
//  Copyright © 2017 Student. All rights reserved.
//

import XCTest
@testable import MyFirstApp

class MyFirstAppTests: XCTestCase {
    
    
    
    var mySimpleInterestCalculator: simpleInterest = simpleInterest()
    
    func testSimpleInterest(){
        //this is an examle of a functional test
        
        var result : Double
        
        
        result = mySimpleInterestCalculator.calculate(loanAmount: 25000, years: 10, interestRate: 8)
        
        XCTAssertEqualWithAccuracy(result,45000, accuracy: 0.1)
    }
    
    
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
