//
//  Clock.swift
//  Clock
//
//  Created by Student on 4/27/17.
//  Copyright © 2017 Student. All rights reserved.
//

import Foundation


class Clock {
    var currentTime: NSDate {
        return NSDate()
    } 
}
