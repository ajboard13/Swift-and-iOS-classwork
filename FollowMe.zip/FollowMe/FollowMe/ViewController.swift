//
//  ViewController.swift
//  FollowMe
//
//  Created by Student on 3/23/17.
//  Copyright © 2017 Student. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIAlertViewDelegate{

    @IBOutlet weak var redButton: UIButton!
    @IBOutlet weak var greenButton: UIButton!
    @IBOutlet weak var blueButton: UIButton!
    @IBOutlet weak var yellowButton: UIButton!
    
    enum buttonColor : Int {
        case red = 1
        case green = 2
        case blue = 3
        case yellow = 4
    }
    
    enum whoseTurn {
        case Human
        case Computer
    }
    
    let winningNumber: Int = 7
    var currentPlayer: whoseTurn = .Computer
    var inputs = [buttonColor]()
    var indexOfNextButtonTotouch: Int = 0
    var highlightSquareTime = 0.5
    
    override func viewDidAppear(_ animated: Bool) {
        startNewGame()
    }
    
    func buttonByColor(color: buttonColor) -> UIButton {
        switch color{
            case .green: return greenButton
            case .red: return redButton
            case .blue: return blueButton
            case .yellow: return yellowButton
        }
    }
    
    func playSequence(index: Int, highlightTime: Double){
        currentPlayer = .Computer
        
        if index == inputs.count {
            currentPlayer = .Human
            return
        }
        
        let button: UIButton = buttonByColor(color: inputs[index])
        let originalColor: UIColor? = button.backgroundColor
        let highlightedColor: UIColor = UIColor.white
        UIView.animate(withDuration: highlightTime,
                       delay: 0.0,
                       options: .curveLinear,
                       animations: {button.backgroundColor = highlightedColor},
                       completion: {finished in button.backgroundColor = originalColor
                                    let newIndex: Int = index + 1
                                    self.playSequence(index: newIndex,
                                                      highlightTime: highlightTime)})
        
    }
    
    @IBAction func buttonTouched(_ sender: UIButton){
        let buttonTag: Int = sender.tag
        
        if let colorTouched = buttonColor(rawValue: buttonTag){
            if currentPlayer == .Computer{
                return
            }
            if colorTouched == inputs[indexOfNextButtonTotouch]{
                indexOfNextButtonTotouch = indexOfNextButtonTotouch + 1
                if indexOfNextButtonTotouch == inputs.count {
                    if advanceGame() == false {
                        playerWins()
                    }
                    indexOfNextButtonTotouch = 0
                }
                else{
                    
                }
            }
            else {
                playerLoses()
                indexOfNextButtonTotouch = 0
            }
        }
    }
    
    func advanceGame() -> Bool {
        var result: Bool = true
        if inputs.count == winningNumber {
            result = false
        }
        else{
            inputs = inputs + [randomButton()]
            playSequence(index: 0, highlightTime: highlightSquareTime)
        }
        return result
    }
    
    func randomButton() -> buttonColor {
        let v: Int = Int(arc4random_uniform(UInt32(4))) + 1
        let result = buttonColor(rawValue: v)
        return result!
    }
    
    func startNewGame() {
        inputs = [buttonColor]()
        let _ =  advanceGame()
    }
    
    func playerWins() {
        let winner: UIAlertView = UIAlertView(title: "You Won!",
                                             message: "Congrats",
                                             delegate: self,
                                             cancelButtonTitle: nil,
                                             otherButtonTitles: "Try Again?")
        
        winner.show()
    }
    
    func playerLoses() {
        let loser: UIAlertView = UIAlertView(title: "You Lost!",
                                             message: "Sorry",
                                             delegate: self,
                                             cancelButtonTitle: nil,
                                             otherButtonTitles: "Try Again?")
        
        loser.show()
    }
    
    func alertView(_ alertView: UIAlertView, clickedButtonAt buttonIndex: Int){
        startNewGame()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

