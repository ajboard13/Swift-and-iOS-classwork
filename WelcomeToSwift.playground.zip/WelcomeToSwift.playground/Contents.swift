/*
 my first playground app - Aaron Board
 */

import UIKit

var str = "Hello, my name is Aaron Board and I'm looking forward to learning Swift and iOS"

print(str)

var heart = "❤️"

print("I \(heart) Swift and iOS!")

var xPosition = 150
print(xPosition)

xPosition = 200

print(Int.min)
print(Int.max)

print(UInt.min)
print(UInt.max)

var someNumber : Double = 3

print(someNumber)

var myState : String = "Michigan"
print(myState)


let saySomething = "I love " + myState
print(saySomething)

let someChar : Character = "A"
print(someChar)

var addTheseTwoNumbers = 2+2
print(addTheseTwoNumbers)

var binNumber = 0b110011
print(binNumber)


var testThis = saySomething + " ...NOT"


var octNumber = 0o12
print(octNumber)

var hexNumber = 0x32
let sciNot = 3.34e-10
print(sciNot)

var fiveMillion = 5_000_000_000

"a">"b"

var myDreamCar = (2017,"Mercedes-Bez", "S-Class")

print(myDreamCar.0)
print(myDreamCar.1)
print(myDreamCar.2)

