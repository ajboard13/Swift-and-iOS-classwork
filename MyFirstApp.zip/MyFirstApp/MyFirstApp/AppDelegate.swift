//
//  AppDelegate.swift
//  MyFirstApp
//
//  Created by Student on 2/16/17.
//  Copyright © 2017 Student. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    @IBOutlet weak var window: NSWindow!
    
    
    //model
    var simpleInterestCalculator : simpleInterest = simpleInterest()
    
    @IBOutlet weak var loanAmountTextField: NSTextField!
    @IBOutlet weak var loanTermTextField: NSTextField!
    @IBOutlet weak var resultDisplayField: NSTextField!
    @IBOutlet weak var interestRateTextField: NSTextField!
    @IBAction func calculateButton(_ sender: NSButton) {
        var result : Double
        result = simpleInterestCalculator.calculate(loanAmount:loanAmountTextField.doubleValue, years: loanTermTextField.integerValue, interestRate: interestRateTextField.doubleValue)
        self.resultDisplayField.stringValue = String(format: "$%.2f",result)
    }
    
    
    


    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

